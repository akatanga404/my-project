function toggleForms() {
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');
    loginForm.classList.toggle('d-none');
    signupForm.classList.toggle('d-none');
}

function signup(event) {
    event.preventDefault();
    const username = document.getElementById('signup-username').value;
    const password = document.getElementById('signup-password').value;

    console.log('User  Registered:', { username, password });

    alert('Registration successful! Redirecting to homepage...');
    window.location.href = 'index.html'; 
}

function login(event) {
    event.preventDefault();
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    console.log('User  Logged In:', { username, password });

    alert('Login successful! Redirecting to homepage...');
    window.location.href = 'index.html';
}